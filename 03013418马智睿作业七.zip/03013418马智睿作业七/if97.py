import math
n = [0.14632971213167, -0.84548187169114, -3.7563603672040, 3.3855169168385, -0.95791963387872, 0.15772038513228, -0.016616417199501, 0.00081214629983568, 0.00028319080123804, -0.00060706301565874, -0.018990068218419, -0.032529748770505, -0.021841717175414, -0.000052838357969930, -0.00047184321073267, -0.00030001780793026, 0.000047661393906987, -0.0000044141845330846, -0.00000000000000072694996297594, -0.000031679644845054, -
     0.0000028270797985312, -0.00000000085205128120103, -0.0000022425281908000, -0.00000065171222895601, -0.00000000000014341729937924, -0.00000040516996860117, -0.0000000012734301741641, -0.00000000017424871230634, -0.00000000000000000068762131295531, 0.000000000000000000014478307828521, 0.000000000000000000000026335781662795, -0.000000000000000000000011947622640071, 0.0000000000000000000000018228094581404, -0.000000000000000000000000093537087292458]
I = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2,
     2, 3, 3, 3, 4, 4, 4, 5, 8, 8, 21, 23, 29, 30, 31, 32]
J = [-2, -1, 0, 1, 2, 3, 4, 5, -9, -7, -1, 0, 1, 3, -3, 0, 1, 3, 17, -
     4, 0, 6, -5, -2, 10, -8, -11, -6, -29, -31, -38, -39, -40, -41]

PP = 16.53
TT = 1386
RR = 0.461526


def gama(p, t):
    pi = p / PP
    tao = TT / t
    gm = 0
    for i in range(1, 35):
        gm += n[i - 1] * (7.1 - pi)**I[i - 1] * (tao - 1.222)**J[i - 1]
    return gm


def gamapai(p, t):
    pi = p / PP
    tao = TT / t
    gmp = 0
    for i in range(1, 35):
        gmp -= n[i - 1] * I[i - 1] * (7.1 - pi)**(I[i - 1] - 1) * (tao - 1.222)**J[i - 1]
    return gmp


def gamapaipai(p, t):
    pi = p / PP
    tao = TT / t
    gmpp = 0
    for i in range(1, 35):
        gmpp += n[i - 1] * I[i - 1] * (I[i - 1] - 1) * \
            (7.1 - pi)**(I[i - 1] - 2) * (tao - 1.222)**J[i - 1]
    return gmpp


def gamatao(p, t):
    pi = p / PP
    tao = TT / t
    gmt = 0
    for i in range(1, 35):
        gmt += n[i - 1] * (7.1 - pi)**I[i - 1] * J[i - 1] * (tao - 1.222)**(J[i - 1] - 1)
    return gmt


def gamataotao(p, t):
    pi = p / PP
    tao = TT / t
    gmtt = 0
    for i in range(1, 35):
        gmtt += n[i - 1] * (7.1 - pi)**I[i - 1] * J[i - 1] * \
            (J[i - 1] - 1) * (tao - 1.222)**(J[i - 1] - 2)
    return gmtt


def gamapaitao(p, t):
    pi = p / PP
    tao = TT / t
    gmpt = 0
    for i in range(1, 35):
        gmpt -= n[i - 1] * I[i - 1] * (7.1 - pi)**(I[i - 1] - 1) * \
            J[i - 1] * (tao - 1.222)**(J[i - 1] - 1)
    return gmpt


def Volume(p, t):
    pi = p / PP
    vol = pi * gamapai(p, t) * RR * t / (p * 1000)
    return vol


def InternalEnergy(p, t):
    pi = p / PP
    tao = TT / t
    eng = (tao * gamatao(p, t) - pi * gamapai(p, t)) * RR * t
    return eng


def Entropy(p, t):
    tao = TT / t
    ent = (tao * gamatao(p, t) - gama(p, t)) * RR
    return ent


def Enthalpy(p, t):
    tao = TT / t
    ent = tao * gamatao(p, t) * RR * t
    return ent


def IHCapacity(p, t):
    tao = TT / t
    cap = 0 - tao**2 * gamataotao(p, t) * RR
    return cap


def Sound(p, t):
    tao = TT / t
    s1 = gamapai(p, t)**2
    s2 = gamapai(p, t) - tao * gamapaitao(p, t)
    s3 = s2**2
    s4 = tao**2 * gamataotao(p, t)
    s5 = s3 / s4
    sou = (s1 * RR * t * 1000 / (s5 - gamapaipai(p, t)))**0.5
    return sou
