import unittest
import if97


class test(unittest.TestCase):
# Thermodynamic property values calculated from Eq. (7) for selected values of T and pa  from page9
    def setUp(self):
        self.data1 = [[3, 300, 0.0010021516796866943, 115.3312730214384, 112.32481798237833, 0.39229479240262427, 4.173012184067783, 1507.7392096690312],
                      [80, 300, 0.0009711808940216297, 184.14282773425438, 106.44835621252402,
                       0.36856385239848066, 4.010089869646331, 1634.6905431116586],
                      [3, 500, 0.001202418003378339, 975.5422390972251, 971.9349850870901, 2.58041912005181, 4.6558068221112086, 1240.7133731017252]]

    def test_Volume(self):
        for item in self.data1:
            self.assertAlmostEqual(if97.Volume(item[0], item[1]), item[2])

    def test_Enthalpy(self):
        for item in self.data1:
            self.assertAlmostEqual(if97.Enthalpy(item[0], item[1]), item[3])

    def test_InternalEnergy(self):
        for item in self.data1:
            self.assertAlmostEqual(if97.InternalEnergy(item[0], item[1]), item[4])

    def test_Entropy(self):
        for item in self.data1:
            self.assertEqual(if97.Entropy(item[0], item[1]), item[5])

    def test_IHCapacity(self):
        for item in self.data1:
            self.assertEqual(if97.IHCapacity(item[0], item[1]), item[6])

    def test_Sound(self):
        for item in self.data1:
            self.assertEqual(if97.Sound(item[0], item[1]), item[7])