
import matplotlib.pyplot as plt
import numpy as np
import math
from  statistics import mean,stdev,pstdev,variance,pvariance

from prettytable import PrettyTable
import glob

file=[]

xy=[]#一组x，y数组

xsta={'avg':None,'stdev':None,'pstdev':None,'var':None,'pvar':None}#x特征值map
ysta={'avg':None,'stdev':None,'pstdev':None,'var':None,'pvar':None}#y特征值map

a#x的自由度
b#y的自由度
predictedY#对Y的预测

xyArrays=[]#四组xy

xStaArrays=[]#x数据特征值数组
yStaArrays=[]#y数据特征值数据
rArrays=[]#回归系数数组

lfitArrays=[]#相关性

if __name__ == '__main__':

    file=glob.glob(r'./Anscombe*.txt')
    
    #进行数据录入
    for i in range(len(file)):
        #一次录入并分析一组数据
        openFile = poen(file[i],'r')

        xy={'x':[],'y':[]}

        readMessage = openFile.readline()

        for line in openFile:
            x,y = line.split()
            xy['x'].append(float(x))
            xy['y'].append(float(y))

        openFile.close()

        #计算数据特征值

        xsta['avg']=mean(x)#平均值
        ysta['avg']=mean(y)

        xsta['stdev']=stdev(x)#标准差
        ysta['stdev']=stdev(y)

        xsta['pstdev']=pstdev(x)
        ysta['pstdev']=pstdev(y)

        xsta['var']=variance(x)#方差
        ysta['var']=variance(y)

        xsta['pvar']=pvariance(x)
        ysta['pvar']=pvariance(y)

        r=np.corrcoef(x,y)[0, 1]

        #fit data 
        a,b = np.polyfit(x,y,1) #计算自由度
        predictedY = a*np.array(x) + b #对Y的预测

        xyArrays.append(xy)
        xStaArrays.append(xsta)
        yStaArrays.append(ysta)
        rArrays.append(r)

        lfitArrays.append({'a':a,'b':b,'preY':predictedY})
    #结束


    #将内容如表格方式整齐输出
    table = PrettyTable(["data set",
                "x-avg", "x-std", "x-pstd", "x-var","x-pvar",
                            "y-avg", "y-std", "y-pstd", "y-var","y-pvar",
                            "pearson_r"])

    table.align= "r" # right align
    table.padding_width = 1 # One space between column edges and contents (default)

    for i in range(len(file)):
        table.add_row(
                     [
                      file[i],
                       "%.3f" % xStaArrays[i]['avg'],
                       "%.3f" % xStaArrays[i]['stdev'],"%.3f" %xStaArrays[i]['pstdev'],
                       "%.3f" % xStaArrays[i]['var'],"%.3f" % xStaArrays[i]['pvar'],
                       "%.3f" % yStaArrays[i]['avg'],
                       "%.3f" % yStaArrays[i]['stdev'],"%.3f" % yStaArrays[i]['pstdev'],
                       "%.3f" % yStaArrays[i]['var'],"%.3f" % yStaArrays[i]['pvar'],
                       "%.3f" % rArrays[i]
                    ])
    print(table)
    #结束

    #绘图
    fig=plt.figure(figsize=(12.0,8.0))

    fig.subplots_adjust(left=0.05,right=0.95,bottom=0.05,top=0.95)

    figcount=len(filenames)

    figcol=2
    figrow=math.ceil(figcount/figcol)

    for i in range(figcount):
            fig.add_subplot(figrow, figcol,i+1)

         plt.plot(xyArrays[i]['x'],xyArrays[i]['y'],'bo',label=file[i])
         plt.title(file[i])
         plt.xlabel('x')
         plt.ylabel('y')
        
         plt.plot(xyArrays[i]['x'],lfitArrays[i]['preY'],
                label = 'Y by\nnlinear fit, y = '
                + str(round(lfitArrays[i]['a'],5)) + '*x+'+ str(round(lfitArrays[i]['b']))
         plt.legend(loc = 'best')

    plt.show()
    #结束

#结束






